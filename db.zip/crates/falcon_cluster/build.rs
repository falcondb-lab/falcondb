fn main() {
    // Proto codegen moved to the falcon_proto crate.
    // This build.rs is now a no-op.
}
